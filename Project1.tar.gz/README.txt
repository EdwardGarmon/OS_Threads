compile with :
    g++ main.cc -lpthread

run with :
    ./a.out test.txt

The file output.txt will contain all of the numbers multiplied

Make sure that if this program is being use on the UTD unix servers to 
use test files that have unix standard line endings. 